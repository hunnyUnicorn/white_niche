const degrees = [
  {
    school: 'Tokyo University, Japan',
    degree: 'B.S. Computer Engineering',
    link: 'https://www.u-tokyo.ac.jp/en/',
    year: 2015,
  },
];

export default degrees;
