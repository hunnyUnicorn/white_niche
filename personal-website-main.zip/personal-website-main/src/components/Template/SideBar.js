import React from 'react';
import { Link } from 'react-router-dom';

import ContactIcons from '../Contact/ContactIcons';

const { PUBLIC_URL } = process.env; // set automatically from package.json:homepage

const SideBar = () => (
  <section id="sidebar">
    <section id="intro">
      <Link to="/" className="logo">
        <img src={`${PUBLIC_URL}/images/Gian.jpg`} alt="" />
      </Link>
      <header>
        <h2>Gian Franco De La Mendoza</h2>
        <p><a href="crash.delamendoza@gmail.com">crash.delamendoza@gmail.com</a></p>
      </header>
    </section>

    <section className="blurb">
      <h2>About</h2>
      <p>
        <b>Organized</b>, <b>collaborative</b>, and <b>highly skilled</b>
        <> </>software developer with 6+ years of experience.
        <b>Self-motivated</b> and <b>self-taught</b> professional who likes to solve problems.
      </p>
      <ul className="actions">
        <li>
          {!window.location.pathname.includes('/resume') ? <Link to="/resume" className="button">Learn More</Link> : <Link to="/about" className="button">About Me</Link>}
        </li>
      </ul>
    </section>

    <section id="footer">
      <ContactIcons />
      <p className="copyright">&copy; Crash <Link to="/">gianfranco.com</Link>.</p>
    </section>
  </section>
);

export default SideBar;
